--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.5 (Ubuntu 10.5-1.pgdg16.04+1)
-- Dumped by pg_dump version 10.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.proj_postbox DROP CONSTRAINT proj_postbox_site_id_cd03f46d_fk_django_site_id;
ALTER TABLE ONLY public.proj_postbox DROP CONSTRAINT proj_postbox_agent_id_84c303f6_fk_auth_user_id;
ALTER TABLE ONLY public.proj_gallery_imagegeneric DROP CONSTRAINT proj_gallery_imagege_image_id_5d6cbdd2_fk_proj_gallery_image_id;
ALTER TABLE ONLY public.proj_gallery_imagegeneric DROP CONSTRAINT proj_gallery_content_type_id_9ae687f5_fk_django_content_type_id;
ALTER TABLE ONLY public.proj_gallery_albomgeneric DROP CONSTRAINT proj_gallery_content_type_id_6604f974_fk_django_content_type_id;
ALTER TABLE ONLY public.proj_gallery_albomthrough DROP CONSTRAINT proj_gallery_albomth_image_id_248d71ee_fk_proj_gallery_image_id;
ALTER TABLE ONLY public.proj_gallery_albomthrough DROP CONSTRAINT proj_gallery_albomth_albom_id_d9278177_fk_proj_gallery_albom_id;
ALTER TABLE ONLY public.proj_gallery_albomgeneric DROP CONSTRAINT proj_gallery_albomge_albom_id_90d05db2_fk_proj_gallery_albom_id;
ALTER TABLE ONLY public.proj_content DROP CONSTRAINT proj_content_parent_id_75eab75e_fk_proj_content_id;
ALTER TABLE ONLY public.proj_content DROP CONSTRAINT proj_content_create_by_id_eb408158_fk_auth_user_id;
ALTER TABLE ONLY public.proj_content DROP CONSTRAINT proj_content_change_by_id_d0d098b0_fk_auth_user_id;
ALTER TABLE ONLY public.proj_callback DROP CONSTRAINT proj_callback_site_id_d6c6709c_fk_django_site_id;
ALTER TABLE ONLY public.proj_callback DROP CONSTRAINT proj_callback_agent_id_2d291643_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id;
ALTER TABLE ONLY public.cck_permit DROP CONSTRAINT cck_permit_create_by_id_b52e25f0_fk_auth_user_id;
ALTER TABLE ONLY public.cck_permit DROP CONSTRAINT cck_permit_change_by_id_46938fb1_fk_auth_user_id;
ALTER TABLE ONLY public.cck_object DROP CONSTRAINT cck_object_create_by_id_dfdb299d_fk_auth_user_id;
ALTER TABLE ONLY public.cck_object DROP CONSTRAINT cck_object_change_by_id_b1ed2c1a_fk_auth_user_id;
ALTER TABLE ONLY public.cck_object_activity DROP CONSTRAINT cck_object_activity_object_id_ceb64583_fk_cck_object_id;
ALTER TABLE ONLY public.cck_object_activity DROP CONSTRAINT cck_object_activity_activity_id_d56b9999_fk_cck_activity_id;
ALTER TABLE ONLY public.cck_news DROP CONSTRAINT cck_news_create_by_id_ae4544ed_fk_auth_user_id;
ALTER TABLE ONLY public.cck_news DROP CONSTRAINT cck_news_change_by_id_1bc680ef_fk_auth_user_id;
ALTER TABLE ONLY public.cck_activity DROP CONSTRAINT cck_activity_create_by_id_e42ab46f_fk_auth_user_id;
ALTER TABLE ONLY public.cck_activity DROP CONSTRAINT cck_activity_change_by_id_0711b730_fk_auth_user_id;
ALTER TABLE ONLY public.cck_activity_article DROP CONSTRAINT cck_activity_article_parent_id_2daa8730_fk_cck_activity_id;
ALTER TABLE ONLY public.cck_activity_article DROP CONSTRAINT cck_activity_article_create_by_id_d3acc17b_fk_auth_user_id;
ALTER TABLE ONLY public.cck_activity_article DROP CONSTRAINT cck_activity_article_change_by_id_8bad7434_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id;
DROP INDEX public.proj_postbox_subject_cbd599bd_like;
DROP INDEX public.proj_postbox_state_dd798295_like;
DROP INDEX public.proj_postbox_name_b74bcde2_like;
DROP INDEX public.proj_postbox_email_033c5661_like;
DROP INDEX public.proj_postbox_b5e3374e;
DROP INDEX public.proj_postbox_b068931c;
DROP INDEX public.proj_postbox_adc78145;
DROP INDEX public.proj_postbox_9ed39e2e;
DROP INDEX public.proj_postbox_9b18f05f;
DROP INDEX public.proj_postbox_9365d6e7;
DROP INDEX public.proj_postbox_0c83f57c;
DROP INDEX public.proj_gallery_imagegeneric_f33175e6;
DROP INDEX public.proj_gallery_imagegeneric_6a992d55;
DROP INDEX public.proj_gallery_imagegeneric_417f1b1c;
DROP INDEX public.proj_gallery_image_type_8cebf618_like;
DROP INDEX public.proj_gallery_image_name_438f4fae_like;
DROP INDEX public.proj_gallery_image_c76a5e84;
DROP INDEX public.proj_gallery_image_b068931c;
DROP INDEX public.proj_gallery_image_6a992d55;
DROP INDEX public.proj_gallery_image_599dcce2;
DROP INDEX public.proj_gallery_albomthrough_f33175e6;
DROP INDEX public.proj_gallery_albomthrough_6a992d55;
DROP INDEX public.proj_gallery_albomthrough_00049261;
DROP INDEX public.proj_gallery_albomgeneric_6a992d55;
DROP INDEX public.proj_gallery_albomgeneric_417f1b1c;
DROP INDEX public.proj_gallery_albomgeneric_00049261;
DROP INDEX public.proj_gallery_albom_name_c7196fe7_like;
DROP INDEX public.proj_gallery_albom_c76a5e84;
DROP INDEX public.proj_gallery_albom_b068931c;
DROP INDEX public.proj_gallery_albom_6a992d55;
DROP INDEX public.proj_gallery_albom_4c9184f3;
DROP INDEX public.proj_content_slug_791d5862_like;
DROP INDEX public.proj_content_locale_001e7ad3_like;
DROP INDEX public.proj_content_fb216d9e;
DROP INDEX public.proj_content_d18b8f17;
DROP INDEX public.proj_content_be81f71c;
DROP INDEX public.proj_content_b6a36216;
DROP INDEX public.proj_content_a0413764;
DROP INDEX public.proj_content_8f888fed;
DROP INDEX public.proj_content_6be37982;
DROP INDEX public.proj_content_6a992d55;
DROP INDEX public.proj_content_402bbb5d;
DROP INDEX public.proj_content_2dbcba41;
DROP INDEX public.proj_content_0fa44e66;
DROP INDEX public.proj_content_0d111f56;
DROP INDEX public.proj_content_06b2d4b9;
DROP INDEX public.proj_content_0382892d;
DROP INDEX public.proj_callback_phone_409a4dd6_like;
DROP INDEX public.proj_callback_name_96d86c67_like;
DROP INDEX public.proj_callback_f7a42fe7;
DROP INDEX public.proj_callback_b068931c;
DROP INDEX public.proj_callback_adc78145;
DROP INDEX public.proj_callback_9ed39e2e;
DROP INDEX public.proj_callback_9b18f05f;
DROP INDEX public.proj_callback_9365d6e7;
DROP INDEX public.django_site_domain_a2e37b91_like;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.cck_permit_slug_eeea6537_like;
DROP INDEX public.cck_permit_owner_d89f4808_like;
DROP INDEX public.cck_permit_locale_9a5761ff_like;
DROP INDEX public.cck_permit_fb216d9e;
DROP INDEX public.cck_permit_d18b8f17;
DROP INDEX public.cck_permit_be81f71c;
DROP INDEX public.cck_permit_8f888fed;
DROP INDEX public.cck_permit_72122ce9;
DROP INDEX public.cck_permit_6a992d55;
DROP INDEX public.cck_permit_2dbcba41;
DROP INDEX public.cck_permit_0d111f56;
DROP INDEX public.cck_permit_0382892d;
DROP INDEX public.cck_object_slug_b107cdf5_like;
DROP INDEX public.cck_object_locale_0b2fdc9f_like;
DROP INDEX public.cck_object_fb216d9e;
DROP INDEX public.cck_object_d18b8f17;
DROP INDEX public.cck_object_be81f71c;
DROP INDEX public.cck_object_activity_f8a3193a;
DROP INDEX public.cck_object_activity_af31437c;
DROP INDEX public.cck_object_8f888fed;
DROP INDEX public.cck_object_6a992d55;
DROP INDEX public.cck_object_5157e3c7;
DROP INDEX public.cck_object_2dbcba41;
DROP INDEX public.cck_object_0d111f56;
DROP INDEX public.cck_object_0382892d;
DROP INDEX public.cck_news_slug_8bbbdb0c_like;
DROP INDEX public.cck_news_locale_2f58b2cb_like;
DROP INDEX public.cck_news_fb216d9e;
DROP INDEX public.cck_news_d18b8f17;
DROP INDEX public.cck_news_be81f71c;
DROP INDEX public.cck_news_8f888fed;
DROP INDEX public.cck_news_6a992d55;
DROP INDEX public.cck_news_2dbcba41;
DROP INDEX public.cck_news_0d111f56;
DROP INDEX public.cck_news_0382892d;
DROP INDEX public.cck_activity_slug_843e304f_like;
DROP INDEX public.cck_activity_locale_e6683af2_like;
DROP INDEX public.cck_activity_fb216d9e;
DROP INDEX public.cck_activity_d18b8f17;
DROP INDEX public.cck_activity_be81f71c;
DROP INDEX public.cck_activity_article_slug_8d41f734_like;
DROP INDEX public.cck_activity_article_d18b8f17;
DROP INDEX public.cck_activity_article_be81f71c;
DROP INDEX public.cck_activity_article_8f888fed;
DROP INDEX public.cck_activity_article_6be37982;
DROP INDEX public.cck_activity_article_6a992d55;
DROP INDEX public.cck_activity_article_0d111f56;
DROP INDEX public.cck_activity_article_0382892d;
DROP INDEX public.cck_activity_8f888fed;
DROP INDEX public.cck_activity_6a992d55;
DROP INDEX public.cck_activity_2dbcba41;
DROP INDEX public.cck_activity_0d111f56;
DROP INDEX public.cck_activity_0382892d;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.proj_postbox DROP CONSTRAINT proj_postbox_pkey;
ALTER TABLE ONLY public.proj_gallery_imagegeneric DROP CONSTRAINT proj_gallery_imagegeneric_pkey;
ALTER TABLE ONLY public.proj_gallery_imagegeneric DROP CONSTRAINT proj_gallery_imagegeneric_content_type_id_e403d9a1_uniq;
ALTER TABLE ONLY public.proj_gallery_image DROP CONSTRAINT proj_gallery_image_pkey;
ALTER TABLE ONLY public.proj_gallery_albomthrough DROP CONSTRAINT proj_gallery_albomthrough_pkey;
ALTER TABLE ONLY public.proj_gallery_albomthrough DROP CONSTRAINT proj_gallery_albomthrough_albom_id_1fb02d1f_uniq;
ALTER TABLE ONLY public.proj_gallery_albomgeneric DROP CONSTRAINT proj_gallery_albomgeneric_pkey;
ALTER TABLE ONLY public.proj_gallery_albomgeneric DROP CONSTRAINT proj_gallery_albomgeneric_content_type_id_63d7aa53_uniq;
ALTER TABLE ONLY public.proj_gallery_albom DROP CONSTRAINT proj_gallery_albom_pkey;
ALTER TABLE ONLY public.proj_content DROP CONSTRAINT proj_content_pkey;
ALTER TABLE ONLY public.proj_content DROP CONSTRAINT proj_content_locale_4c4b1c28_uniq;
ALTER TABLE ONLY public.proj_callback DROP CONSTRAINT proj_callback_pkey;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_pkey;
ALTER TABLE ONLY public.django_site DROP CONSTRAINT django_site_domain_a2e37b91_uniq;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.cck_permit DROP CONSTRAINT cck_permit_pkey;
ALTER TABLE ONLY public.cck_permit DROP CONSTRAINT cck_permit_locale_2095f5d1_uniq;
ALTER TABLE ONLY public.cck_object DROP CONSTRAINT cck_object_pkey;
ALTER TABLE ONLY public.cck_object DROP CONSTRAINT cck_object_locale_e32b0d73_uniq;
ALTER TABLE ONLY public.cck_object_activity DROP CONSTRAINT cck_object_activity_pkey;
ALTER TABLE ONLY public.cck_object_activity DROP CONSTRAINT cck_object_activity_object_id_5290fd78_uniq;
ALTER TABLE ONLY public.cck_news DROP CONSTRAINT cck_news_pkey;
ALTER TABLE ONLY public.cck_news DROP CONSTRAINT cck_news_locale_984c44d9_uniq;
ALTER TABLE ONLY public.cck_activity DROP CONSTRAINT cck_activity_pkey;
ALTER TABLE ONLY public.cck_activity DROP CONSTRAINT cck_activity_locale_77226f1e_uniq;
ALTER TABLE ONLY public.cck_activity_article DROP CONSTRAINT cck_activity_article_slug_key;
ALTER TABLE ONLY public.cck_activity_article DROP CONSTRAINT cck_activity_article_pkey;
ALTER TABLE ONLY public.cck_activity_article DROP CONSTRAINT cck_activity_article_parent_id_da00d64e_uniq;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.proj_postbox ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proj_gallery_imagegeneric ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proj_gallery_image ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proj_gallery_albomthrough ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proj_gallery_albomgeneric ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proj_gallery_albom ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proj_content ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.proj_callback ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_site ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cck_permit ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cck_object_activity ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cck_object ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cck_news ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cck_activity_article ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.cck_activity ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.proj_postbox_id_seq;
DROP TABLE public.proj_postbox;
DROP SEQUENCE public.proj_gallery_imagegeneric_id_seq;
DROP TABLE public.proj_gallery_imagegeneric;
DROP SEQUENCE public.proj_gallery_image_id_seq;
DROP TABLE public.proj_gallery_image;
DROP SEQUENCE public.proj_gallery_albomthrough_id_seq;
DROP TABLE public.proj_gallery_albomthrough;
DROP SEQUENCE public.proj_gallery_albomgeneric_id_seq;
DROP TABLE public.proj_gallery_albomgeneric;
DROP SEQUENCE public.proj_gallery_albom_id_seq;
DROP TABLE public.proj_gallery_albom;
DROP SEQUENCE public.proj_content_id_seq;
DROP TABLE public.proj_content;
DROP SEQUENCE public.proj_callback_id_seq;
DROP TABLE public.proj_callback;
DROP SEQUENCE public.django_site_id_seq;
DROP TABLE public.django_site;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.cck_permit_id_seq;
DROP TABLE public.cck_permit;
DROP SEQUENCE public.cck_object_id_seq;
DROP SEQUENCE public.cck_object_activity_id_seq;
DROP TABLE public.cck_object_activity;
DROP TABLE public.cck_object;
DROP SEQUENCE public.cck_news_id_seq;
DROP TABLE public.cck_news;
DROP SEQUENCE public.cck_activity_id_seq;
DROP SEQUENCE public.cck_activity_article_id_seq;
DROP TABLE public.cck_activity_article;
DROP TABLE public.cck_activity;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO vps;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO vps;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.auth_group_id_seq OWNED BY public.auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO vps;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO vps;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.auth_group_permissions_id_seq OWNED BY public.auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO vps;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO vps;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.auth_permission_id_seq OWNED BY public.auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO vps;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO vps;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO vps;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.auth_user_groups_id_seq OWNED BY public.auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO vps;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.auth_user_id_seq OWNED BY public.auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO vps;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO vps;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.auth_user_user_permissions_id_seq OWNED BY public.auth_user_user_permissions.id;


--
-- Name: cck_activity; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.cck_activity (
    id integer NOT NULL,
    locale character varying(2),
    index integer NOT NULL,
    robots character varying(32),
    title character varying(255),
    keywords character varying(255),
    description character varying(255),
    name character varying(255),
    label character varying(80),
    aliace character varying(1024),
    slug character varying(1024),
    published boolean NOT NULL,
    published_date date,
    archived boolean NOT NULL,
    create_date timestamp with time zone NOT NULL,
    change_date timestamp with time zone NOT NULL,
    annotation text,
    content text NOT NULL,
    change_by_id integer,
    create_by_id integer,
    CONSTRAINT cck_activity_index_check CHECK ((index >= 0))
);


ALTER TABLE public.cck_activity OWNER TO vps;

--
-- Name: cck_activity_article; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.cck_activity_article (
    id integer NOT NULL,
    index integer NOT NULL,
    robots character varying(32),
    title character varying(255),
    keywords character varying(255),
    description character varying(255),
    name character varying(255),
    label character varying(80),
    aliace character varying(1024),
    slug character varying(1024),
    published boolean NOT NULL,
    published_date date,
    archived boolean NOT NULL,
    create_date timestamp with time zone NOT NULL,
    change_date timestamp with time zone NOT NULL,
    content text NOT NULL,
    change_by_id integer,
    create_by_id integer,
    parent_id integer,
    CONSTRAINT cck_activity_article_index_check CHECK ((index >= 0))
);


ALTER TABLE public.cck_activity_article OWNER TO vps;

--
-- Name: cck_activity_article_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.cck_activity_article_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cck_activity_article_id_seq OWNER TO vps;

--
-- Name: cck_activity_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.cck_activity_article_id_seq OWNED BY public.cck_activity_article.id;


--
-- Name: cck_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.cck_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cck_activity_id_seq OWNER TO vps;

--
-- Name: cck_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.cck_activity_id_seq OWNED BY public.cck_activity.id;


--
-- Name: cck_news; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.cck_news (
    id integer NOT NULL,
    locale character varying(2),
    index integer NOT NULL,
    robots character varying(32),
    title character varying(255),
    keywords character varying(255),
    description character varying(255),
    name character varying(255),
    label character varying(80),
    aliace character varying(1024),
    slug character varying(1024),
    published boolean NOT NULL,
    published_date date,
    archived boolean NOT NULL,
    create_date timestamp with time zone NOT NULL,
    change_date timestamp with time zone NOT NULL,
    annotation text,
    content text NOT NULL,
    tags character varying(32)[],
    source character varying(200),
    change_by_id integer,
    create_by_id integer,
    CONSTRAINT cck_news_index_check CHECK ((index >= 0))
);


ALTER TABLE public.cck_news OWNER TO vps;

--
-- Name: cck_news_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.cck_news_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cck_news_id_seq OWNER TO vps;

--
-- Name: cck_news_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.cck_news_id_seq OWNED BY public.cck_news.id;


--
-- Name: cck_object; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.cck_object (
    id integer NOT NULL,
    locale character varying(2),
    index integer NOT NULL,
    robots character varying(32),
    title character varying(255),
    keywords character varying(255),
    description character varying(255),
    name character varying(255),
    label character varying(80),
    aliace character varying(1024),
    slug character varying(1024),
    published boolean NOT NULL,
    published_date date,
    archived boolean NOT NULL,
    create_date timestamp with time zone NOT NULL,
    change_date timestamp with time zone NOT NULL,
    actual boolean NOT NULL,
    address character varying(255) NOT NULL,
    longitude double precision NOT NULL,
    latitude double precision NOT NULL,
    zoom smallint,
    customer character varying(128) NOT NULL,
    developer character varying(128),
    start_date date,
    finish_date date,
    note text,
    change_by_id integer,
    create_by_id integer,
    CONSTRAINT cck_object_index_check CHECK ((index >= 0)),
    CONSTRAINT cck_object_zoom_check CHECK ((zoom >= 0))
);


ALTER TABLE public.cck_object OWNER TO vps;

--
-- Name: cck_object_activity; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.cck_object_activity (
    id integer NOT NULL,
    object_id integer NOT NULL,
    activity_id integer NOT NULL
);


ALTER TABLE public.cck_object_activity OWNER TO vps;

--
-- Name: cck_object_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.cck_object_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cck_object_activity_id_seq OWNER TO vps;

--
-- Name: cck_object_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.cck_object_activity_id_seq OWNED BY public.cck_object_activity.id;


--
-- Name: cck_object_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.cck_object_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cck_object_id_seq OWNER TO vps;

--
-- Name: cck_object_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.cck_object_id_seq OWNED BY public.cck_object.id;


--
-- Name: cck_permit; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.cck_permit (
    id integer NOT NULL,
    locale character varying(2),
    index integer NOT NULL,
    robots character varying(32),
    title character varying(255),
    keywords character varying(255),
    description character varying(255),
    name character varying(255),
    label character varying(80),
    aliace character varying(1024),
    slug character varying(1024),
    published boolean NOT NULL,
    published_date date,
    archived boolean NOT NULL,
    create_date timestamp with time zone NOT NULL,
    change_date timestamp with time zone NOT NULL,
    owner character varying(128) NOT NULL,
    number character varying(128),
    provider character varying(128) NOT NULL,
    issue_date date,
    onset_date date,
    end_date date,
    note text,
    change_by_id integer,
    create_by_id integer,
    CONSTRAINT cck_permit_index_check CHECK ((index >= 0))
);


ALTER TABLE public.cck_permit OWNER TO vps;

--
-- Name: cck_permit_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.cck_permit_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cck_permit_id_seq OWNER TO vps;

--
-- Name: cck_permit_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.cck_permit_id_seq OWNED BY public.cck_permit.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO vps;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO vps;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.django_admin_log_id_seq OWNED BY public.django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO vps;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO vps;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.django_content_type_id_seq OWNED BY public.django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO vps;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_migrations_id_seq OWNER TO vps;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.django_migrations_id_seq OWNED BY public.django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO vps;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO vps;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO vps;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.django_site_id_seq OWNED BY public.django_site.id;


--
-- Name: proj_callback; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_callback (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    phone character varying(128) NOT NULL,
    sent_date timestamp with time zone NOT NULL,
    state boolean,
    note text,
    agent_id integer,
    site_id integer
);


ALTER TABLE public.proj_callback OWNER TO vps;

--
-- Name: proj_callback_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_callback_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_callback_id_seq OWNER TO vps;

--
-- Name: proj_callback_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_callback_id_seq OWNED BY public.proj_callback.id;


--
-- Name: proj_content; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_content (
    id integer NOT NULL,
    locale character varying(2),
    index integer NOT NULL,
    robots character varying(32),
    title character varying(255),
    keywords character varying(255),
    description character varying(255),
    name character varying(255),
    label character varying(80),
    aliace character varying(1024),
    slug character varying(1024),
    published boolean NOT NULL,
    published_date date,
    archived boolean NOT NULL,
    create_date timestamp with time zone NOT NULL,
    change_date timestamp with time zone NOT NULL,
    cluster boolean NOT NULL,
    annotation text,
    content text NOT NULL,
    source character varying(255),
    layout character varying(255),
    mptt_left integer NOT NULL,
    mptt_right integer NOT NULL,
    mptt_tree integer NOT NULL,
    mptt_level integer NOT NULL,
    change_by_id integer,
    create_by_id integer,
    parent_id integer,
    CONSTRAINT proj_content_index_check CHECK ((index >= 0)),
    CONSTRAINT proj_content_mptt_left_check CHECK ((mptt_left >= 0)),
    CONSTRAINT proj_content_mptt_level_check CHECK ((mptt_level >= 0)),
    CONSTRAINT proj_content_mptt_right_check CHECK ((mptt_right >= 0)),
    CONSTRAINT proj_content_mptt_tree_check CHECK ((mptt_tree >= 0))
);


ALTER TABLE public.proj_content OWNER TO vps;

--
-- Name: proj_content_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_content_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_content_id_seq OWNER TO vps;

--
-- Name: proj_content_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_content_id_seq OWNED BY public.proj_content.id;


--
-- Name: proj_gallery_albom; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_gallery_albom (
    id integer NOT NULL,
    title character varying(255),
    description text,
    active boolean NOT NULL,
    index integer NOT NULL,
    public boolean NOT NULL,
    type character varying(32),
    name character varying(80) NOT NULL,
    CONSTRAINT proj_gallery_albom_index_check CHECK ((index >= 0))
);


ALTER TABLE public.proj_gallery_albom OWNER TO vps;

--
-- Name: proj_gallery_albom_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_gallery_albom_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_gallery_albom_id_seq OWNER TO vps;

--
-- Name: proj_gallery_albom_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_gallery_albom_id_seq OWNED BY public.proj_gallery_albom.id;


--
-- Name: proj_gallery_albomgeneric; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_gallery_albomgeneric (
    id integer NOT NULL,
    title character varying(255),
    description text,
    object_id integer NOT NULL,
    index integer NOT NULL,
    albom_id integer NOT NULL,
    content_type_id integer NOT NULL,
    CONSTRAINT proj_gallery_albomgeneric_index_check CHECK ((index >= 0)),
    CONSTRAINT proj_gallery_albomgeneric_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.proj_gallery_albomgeneric OWNER TO vps;

--
-- Name: proj_gallery_albomgeneric_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_gallery_albomgeneric_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_gallery_albomgeneric_id_seq OWNER TO vps;

--
-- Name: proj_gallery_albomgeneric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_gallery_albomgeneric_id_seq OWNED BY public.proj_gallery_albomgeneric.id;


--
-- Name: proj_gallery_albomthrough; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_gallery_albomthrough (
    id integer NOT NULL,
    title character varying(255),
    description text,
    alt character varying(255),
    index integer NOT NULL,
    albom_id integer NOT NULL,
    image_id integer NOT NULL,
    CONSTRAINT proj_gallery_albomthrough_index_check CHECK ((index >= 0))
);


ALTER TABLE public.proj_gallery_albomthrough OWNER TO vps;

--
-- Name: proj_gallery_albomthrough_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_gallery_albomthrough_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_gallery_albomthrough_id_seq OWNER TO vps;

--
-- Name: proj_gallery_albomthrough_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_gallery_albomthrough_id_seq OWNED BY public.proj_gallery_albomthrough.id;


--
-- Name: proj_gallery_image; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_gallery_image (
    id integer NOT NULL,
    title character varying(255),
    description text,
    active boolean NOT NULL,
    index integer NOT NULL,
    alt character varying(255),
    file character varying(100),
    path character varying(64),
    type character varying(32),
    name character varying(128),
    CONSTRAINT proj_gallery_image_index_check CHECK ((index >= 0))
);


ALTER TABLE public.proj_gallery_image OWNER TO vps;

--
-- Name: proj_gallery_image_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_gallery_image_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_gallery_image_id_seq OWNER TO vps;

--
-- Name: proj_gallery_image_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_gallery_image_id_seq OWNED BY public.proj_gallery_image.id;


--
-- Name: proj_gallery_imagegeneric; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_gallery_imagegeneric (
    id integer NOT NULL,
    title character varying(255),
    description text,
    alt character varying(255),
    index integer NOT NULL,
    object_id integer NOT NULL,
    content_type_id integer NOT NULL,
    image_id integer NOT NULL,
    CONSTRAINT proj_gallery_imagegeneric_index_check CHECK ((index >= 0)),
    CONSTRAINT proj_gallery_imagegeneric_object_id_check CHECK ((object_id >= 0))
);


ALTER TABLE public.proj_gallery_imagegeneric OWNER TO vps;

--
-- Name: proj_gallery_imagegeneric_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_gallery_imagegeneric_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_gallery_imagegeneric_id_seq OWNER TO vps;

--
-- Name: proj_gallery_imagegeneric_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_gallery_imagegeneric_id_seq OWNED BY public.proj_gallery_imagegeneric.id;


--
-- Name: proj_postbox; Type: TABLE; Schema: public; Owner: vps
--

CREATE TABLE public.proj_postbox (
    id integer NOT NULL,
    name character varying(128) NOT NULL,
    email character varying(128) NOT NULL,
    phone character varying(128),
    subject character varying(128),
    message text NOT NULL,
    sent_date timestamp with time zone NOT NULL,
    state character varying(1),
    note text,
    agent_id integer,
    site_id integer
);


ALTER TABLE public.proj_postbox OWNER TO vps;

--
-- Name: proj_postbox_id_seq; Type: SEQUENCE; Schema: public; Owner: vps
--

CREATE SEQUENCE public.proj_postbox_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.proj_postbox_id_seq OWNER TO vps;

--
-- Name: proj_postbox_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: vps
--

ALTER SEQUENCE public.proj_postbox_id_seq OWNED BY public.proj_postbox.id;


--
-- Name: auth_group id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group ALTER COLUMN id SET DEFAULT nextval('public.auth_group_id_seq'::regclass);


--
-- Name: auth_group_permissions id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_group_permissions_id_seq'::regclass);


--
-- Name: auth_permission id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_permission ALTER COLUMN id SET DEFAULT nextval('public.auth_permission_id_seq'::regclass);


--
-- Name: auth_user id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user ALTER COLUMN id SET DEFAULT nextval('public.auth_user_id_seq'::regclass);


--
-- Name: auth_user_groups id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_groups ALTER COLUMN id SET DEFAULT nextval('public.auth_user_groups_id_seq'::regclass);


--
-- Name: auth_user_user_permissions id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('public.auth_user_user_permissions_id_seq'::regclass);


--
-- Name: cck_activity id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity ALTER COLUMN id SET DEFAULT nextval('public.cck_activity_id_seq'::regclass);


--
-- Name: cck_activity_article id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity_article ALTER COLUMN id SET DEFAULT nextval('public.cck_activity_article_id_seq'::regclass);


--
-- Name: cck_news id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_news ALTER COLUMN id SET DEFAULT nextval('public.cck_news_id_seq'::regclass);


--
-- Name: cck_object id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object ALTER COLUMN id SET DEFAULT nextval('public.cck_object_id_seq'::regclass);


--
-- Name: cck_object_activity id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object_activity ALTER COLUMN id SET DEFAULT nextval('public.cck_object_activity_id_seq'::regclass);


--
-- Name: cck_permit id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_permit ALTER COLUMN id SET DEFAULT nextval('public.cck_permit_id_seq'::regclass);


--
-- Name: django_admin_log id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_admin_log ALTER COLUMN id SET DEFAULT nextval('public.django_admin_log_id_seq'::regclass);


--
-- Name: django_content_type id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_content_type ALTER COLUMN id SET DEFAULT nextval('public.django_content_type_id_seq'::regclass);


--
-- Name: django_migrations id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_migrations ALTER COLUMN id SET DEFAULT nextval('public.django_migrations_id_seq'::regclass);


--
-- Name: django_site id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_site ALTER COLUMN id SET DEFAULT nextval('public.django_site_id_seq'::regclass);


--
-- Name: proj_callback id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_callback ALTER COLUMN id SET DEFAULT nextval('public.proj_callback_id_seq'::regclass);


--
-- Name: proj_content id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_content ALTER COLUMN id SET DEFAULT nextval('public.proj_content_id_seq'::regclass);


--
-- Name: proj_gallery_albom id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albom ALTER COLUMN id SET DEFAULT nextval('public.proj_gallery_albom_id_seq'::regclass);


--
-- Name: proj_gallery_albomgeneric id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomgeneric ALTER COLUMN id SET DEFAULT nextval('public.proj_gallery_albomgeneric_id_seq'::regclass);


--
-- Name: proj_gallery_albomthrough id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomthrough ALTER COLUMN id SET DEFAULT nextval('public.proj_gallery_albomthrough_id_seq'::regclass);


--
-- Name: proj_gallery_image id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_image ALTER COLUMN id SET DEFAULT nextval('public.proj_gallery_image_id_seq'::regclass);


--
-- Name: proj_gallery_imagegeneric id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_imagegeneric ALTER COLUMN id SET DEFAULT nextval('public.proj_gallery_imagegeneric_id_seq'::regclass);


--
-- Name: proj_postbox id; Type: DEFAULT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_postbox ALTER COLUMN id SET DEFAULT nextval('public.proj_postbox_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.auth_group (id, name) FROM stdin;
\.
COPY public.auth_group (id, name) FROM '$$PATH$$/3313.dat';

--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY public.auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/3315.dat';

--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY public.auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/3317.dat';

--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/3319.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY public.auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/3320.dat';

--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/3323.dat';

--
-- Data for Name: cck_activity; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.cck_activity (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, annotation, content, change_by_id, create_by_id) FROM stdin;
\.
COPY public.cck_activity (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, annotation, content, change_by_id, create_by_id) FROM '$$PATH$$/3325.dat';

--
-- Data for Name: cck_activity_article; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.cck_activity_article (id, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, content, change_by_id, create_by_id, parent_id) FROM stdin;
\.
COPY public.cck_activity_article (id, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, content, change_by_id, create_by_id, parent_id) FROM '$$PATH$$/3326.dat';

--
-- Data for Name: cck_news; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.cck_news (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, annotation, content, tags, source, change_by_id, create_by_id) FROM stdin;
\.
COPY public.cck_news (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, annotation, content, tags, source, change_by_id, create_by_id) FROM '$$PATH$$/3329.dat';

--
-- Data for Name: cck_object; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.cck_object (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, actual, address, longitude, latitude, zoom, customer, developer, start_date, finish_date, note, change_by_id, create_by_id) FROM stdin;
\.
COPY public.cck_object (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, actual, address, longitude, latitude, zoom, customer, developer, start_date, finish_date, note, change_by_id, create_by_id) FROM '$$PATH$$/3331.dat';

--
-- Data for Name: cck_object_activity; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.cck_object_activity (id, object_id, activity_id) FROM stdin;
\.
COPY public.cck_object_activity (id, object_id, activity_id) FROM '$$PATH$$/3332.dat';

--
-- Data for Name: cck_permit; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.cck_permit (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, owner, number, provider, issue_date, onset_date, end_date, note, change_by_id, create_by_id) FROM stdin;
\.
COPY public.cck_permit (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, owner, number, provider, issue_date, onset_date, end_date, note, change_by_id, create_by_id) FROM '$$PATH$$/3335.dat';

--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/3337.dat';

--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
\.
COPY public.django_content_type (id, app_label, model) FROM '$$PATH$$/3339.dat';

--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
\.
COPY public.django_migrations (id, app, name, applied) FROM '$$PATH$$/3341.dat';

--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY public.django_session (session_key, session_data, expire_date) FROM '$$PATH$$/3343.dat';

--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.django_site (id, domain, name) FROM stdin;
\.
COPY public.django_site (id, domain, name) FROM '$$PATH$$/3344.dat';

--
-- Data for Name: proj_callback; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_callback (id, name, phone, sent_date, state, note, agent_id, site_id) FROM stdin;
\.
COPY public.proj_callback (id, name, phone, sent_date, state, note, agent_id, site_id) FROM '$$PATH$$/3346.dat';

--
-- Data for Name: proj_content; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_content (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, cluster, annotation, content, source, layout, mptt_left, mptt_right, mptt_tree, mptt_level, change_by_id, create_by_id, parent_id) FROM stdin;
\.
COPY public.proj_content (id, locale, index, robots, title, keywords, description, name, label, aliace, slug, published, published_date, archived, create_date, change_date, cluster, annotation, content, source, layout, mptt_left, mptt_right, mptt_tree, mptt_level, change_by_id, create_by_id, parent_id) FROM '$$PATH$$/3348.dat';

--
-- Data for Name: proj_gallery_albom; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_gallery_albom (id, title, description, active, index, public, type, name) FROM stdin;
\.
COPY public.proj_gallery_albom (id, title, description, active, index, public, type, name) FROM '$$PATH$$/3350.dat';

--
-- Data for Name: proj_gallery_albomgeneric; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_gallery_albomgeneric (id, title, description, object_id, index, albom_id, content_type_id) FROM stdin;
\.
COPY public.proj_gallery_albomgeneric (id, title, description, object_id, index, albom_id, content_type_id) FROM '$$PATH$$/3352.dat';

--
-- Data for Name: proj_gallery_albomthrough; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_gallery_albomthrough (id, title, description, alt, index, albom_id, image_id) FROM stdin;
\.
COPY public.proj_gallery_albomthrough (id, title, description, alt, index, albom_id, image_id) FROM '$$PATH$$/3354.dat';

--
-- Data for Name: proj_gallery_image; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_gallery_image (id, title, description, active, index, alt, file, path, type, name) FROM stdin;
\.
COPY public.proj_gallery_image (id, title, description, active, index, alt, file, path, type, name) FROM '$$PATH$$/3356.dat';

--
-- Data for Name: proj_gallery_imagegeneric; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_gallery_imagegeneric (id, title, description, alt, index, object_id, content_type_id, image_id) FROM stdin;
\.
COPY public.proj_gallery_imagegeneric (id, title, description, alt, index, object_id, content_type_id, image_id) FROM '$$PATH$$/3358.dat';

--
-- Data for Name: proj_postbox; Type: TABLE DATA; Schema: public; Owner: vps
--

COPY public.proj_postbox (id, name, email, phone, subject, message, sent_date, state, note, agent_id, site_id) FROM stdin;
\.
COPY public.proj_postbox (id, name, email, phone, subject, message, sent_date, state, note, agent_id, site_id) FROM '$$PATH$$/3360.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 63, true);


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- Name: cck_activity_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.cck_activity_article_id_seq', 4, true);


--
-- Name: cck_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.cck_activity_id_seq', 7, true);


--
-- Name: cck_news_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.cck_news_id_seq', 1, false);


--
-- Name: cck_object_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.cck_object_activity_id_seq', 38, true);


--
-- Name: cck_object_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.cck_object_id_seq', 31, true);


--
-- Name: cck_permit_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.cck_permit_id_seq', 4, true);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 21, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 23, true);


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.django_site_id_seq', 2, true);


--
-- Name: proj_callback_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_callback_id_seq', 1, false);


--
-- Name: proj_content_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_content_id_seq', 1, false);


--
-- Name: proj_gallery_albom_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_gallery_albom_id_seq', 33, true);


--
-- Name: proj_gallery_albomgeneric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_gallery_albomgeneric_id_seq', 1, false);


--
-- Name: proj_gallery_albomthrough_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_gallery_albomthrough_id_seq', 1, false);


--
-- Name: proj_gallery_image_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_gallery_image_id_seq', 66, true);


--
-- Name: proj_gallery_imagegeneric_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_gallery_imagegeneric_id_seq', 1, false);


--
-- Name: proj_postbox_id_seq; Type: SEQUENCE SET; Schema: public; Owner: vps
--

SELECT pg_catalog.setval('public.proj_postbox_id_seq', 1437, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: cck_activity_article cck_activity_article_parent_id_da00d64e_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity_article
    ADD CONSTRAINT cck_activity_article_parent_id_da00d64e_uniq UNIQUE (parent_id, slug);


--
-- Name: cck_activity_article cck_activity_article_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity_article
    ADD CONSTRAINT cck_activity_article_pkey PRIMARY KEY (id);


--
-- Name: cck_activity_article cck_activity_article_slug_key; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity_article
    ADD CONSTRAINT cck_activity_article_slug_key UNIQUE (slug);


--
-- Name: cck_activity cck_activity_locale_77226f1e_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity
    ADD CONSTRAINT cck_activity_locale_77226f1e_uniq UNIQUE (locale, slug);


--
-- Name: cck_activity cck_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity
    ADD CONSTRAINT cck_activity_pkey PRIMARY KEY (id);


--
-- Name: cck_news cck_news_locale_984c44d9_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_news
    ADD CONSTRAINT cck_news_locale_984c44d9_uniq UNIQUE (locale, slug);


--
-- Name: cck_news cck_news_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_news
    ADD CONSTRAINT cck_news_pkey PRIMARY KEY (id);


--
-- Name: cck_object_activity cck_object_activity_object_id_5290fd78_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object_activity
    ADD CONSTRAINT cck_object_activity_object_id_5290fd78_uniq UNIQUE (object_id, activity_id);


--
-- Name: cck_object_activity cck_object_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object_activity
    ADD CONSTRAINT cck_object_activity_pkey PRIMARY KEY (id);


--
-- Name: cck_object cck_object_locale_e32b0d73_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object
    ADD CONSTRAINT cck_object_locale_e32b0d73_uniq UNIQUE (locale, slug);


--
-- Name: cck_object cck_object_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object
    ADD CONSTRAINT cck_object_pkey PRIMARY KEY (id);


--
-- Name: cck_permit cck_permit_locale_2095f5d1_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_permit
    ADD CONSTRAINT cck_permit_locale_2095f5d1_uniq UNIQUE (locale, owner, slug);


--
-- Name: cck_permit cck_permit_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_permit
    ADD CONSTRAINT cck_permit_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: proj_callback proj_callback_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_callback
    ADD CONSTRAINT proj_callback_pkey PRIMARY KEY (id);


--
-- Name: proj_content proj_content_locale_4c4b1c28_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_content
    ADD CONSTRAINT proj_content_locale_4c4b1c28_uniq UNIQUE (locale, slug);


--
-- Name: proj_content proj_content_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_content
    ADD CONSTRAINT proj_content_pkey PRIMARY KEY (id);


--
-- Name: proj_gallery_albom proj_gallery_albom_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albom
    ADD CONSTRAINT proj_gallery_albom_pkey PRIMARY KEY (id);


--
-- Name: proj_gallery_albomgeneric proj_gallery_albomgeneric_content_type_id_63d7aa53_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomgeneric
    ADD CONSTRAINT proj_gallery_albomgeneric_content_type_id_63d7aa53_uniq UNIQUE (content_type_id, object_id, albom_id);


--
-- Name: proj_gallery_albomgeneric proj_gallery_albomgeneric_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomgeneric
    ADD CONSTRAINT proj_gallery_albomgeneric_pkey PRIMARY KEY (id);


--
-- Name: proj_gallery_albomthrough proj_gallery_albomthrough_albom_id_1fb02d1f_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomthrough
    ADD CONSTRAINT proj_gallery_albomthrough_albom_id_1fb02d1f_uniq UNIQUE (albom_id, image_id);


--
-- Name: proj_gallery_albomthrough proj_gallery_albomthrough_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomthrough
    ADD CONSTRAINT proj_gallery_albomthrough_pkey PRIMARY KEY (id);


--
-- Name: proj_gallery_image proj_gallery_image_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_image
    ADD CONSTRAINT proj_gallery_image_pkey PRIMARY KEY (id);


--
-- Name: proj_gallery_imagegeneric proj_gallery_imagegeneric_content_type_id_e403d9a1_uniq; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_imagegeneric
    ADD CONSTRAINT proj_gallery_imagegeneric_content_type_id_e403d9a1_uniq UNIQUE (content_type_id, object_id, image_id);


--
-- Name: proj_gallery_imagegeneric proj_gallery_imagegeneric_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_imagegeneric
    ADD CONSTRAINT proj_gallery_imagegeneric_pkey PRIMARY KEY (id);


--
-- Name: proj_postbox proj_postbox_pkey; Type: CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_postbox
    ADD CONSTRAINT proj_postbox_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_group_permissions_0e939a4f ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_group_permissions_8373b171 ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_permission_417f1b1c ON public.auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_user_groups_0e939a4f ON public.auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_user_groups_e8701ad4 ON public.auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_user_user_permissions_8373b171 ON public.auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON public.auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- Name: cck_activity_0382892d; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_0382892d ON public.cck_activity USING btree (published_date);


--
-- Name: cck_activity_0d111f56; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_0d111f56 ON public.cck_activity USING btree (archived);


--
-- Name: cck_activity_2dbcba41; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_2dbcba41 ON public.cck_activity USING btree (slug);


--
-- Name: cck_activity_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_6a992d55 ON public.cck_activity USING btree (index);


--
-- Name: cck_activity_8f888fed; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_8f888fed ON public.cck_activity USING btree (published);


--
-- Name: cck_activity_article_0382892d; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_0382892d ON public.cck_activity_article USING btree (published_date);


--
-- Name: cck_activity_article_0d111f56; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_0d111f56 ON public.cck_activity_article USING btree (archived);


--
-- Name: cck_activity_article_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_6a992d55 ON public.cck_activity_article USING btree (index);


--
-- Name: cck_activity_article_6be37982; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_6be37982 ON public.cck_activity_article USING btree (parent_id);


--
-- Name: cck_activity_article_8f888fed; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_8f888fed ON public.cck_activity_article USING btree (published);


--
-- Name: cck_activity_article_be81f71c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_be81f71c ON public.cck_activity_article USING btree (create_by_id);


--
-- Name: cck_activity_article_d18b8f17; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_d18b8f17 ON public.cck_activity_article USING btree (change_by_id);


--
-- Name: cck_activity_article_slug_8d41f734_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_article_slug_8d41f734_like ON public.cck_activity_article USING btree (slug varchar_pattern_ops);


--
-- Name: cck_activity_be81f71c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_be81f71c ON public.cck_activity USING btree (create_by_id);


--
-- Name: cck_activity_d18b8f17; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_d18b8f17 ON public.cck_activity USING btree (change_by_id);


--
-- Name: cck_activity_fb216d9e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_fb216d9e ON public.cck_activity USING btree (locale);


--
-- Name: cck_activity_locale_e6683af2_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_locale_e6683af2_like ON public.cck_activity USING btree (locale varchar_pattern_ops);


--
-- Name: cck_activity_slug_843e304f_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_activity_slug_843e304f_like ON public.cck_activity USING btree (slug varchar_pattern_ops);


--
-- Name: cck_news_0382892d; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_0382892d ON public.cck_news USING btree (published_date);


--
-- Name: cck_news_0d111f56; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_0d111f56 ON public.cck_news USING btree (archived);


--
-- Name: cck_news_2dbcba41; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_2dbcba41 ON public.cck_news USING btree (slug);


--
-- Name: cck_news_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_6a992d55 ON public.cck_news USING btree (index);


--
-- Name: cck_news_8f888fed; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_8f888fed ON public.cck_news USING btree (published);


--
-- Name: cck_news_be81f71c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_be81f71c ON public.cck_news USING btree (create_by_id);


--
-- Name: cck_news_d18b8f17; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_d18b8f17 ON public.cck_news USING btree (change_by_id);


--
-- Name: cck_news_fb216d9e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_fb216d9e ON public.cck_news USING btree (locale);


--
-- Name: cck_news_locale_2f58b2cb_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_locale_2f58b2cb_like ON public.cck_news USING btree (locale varchar_pattern_ops);


--
-- Name: cck_news_slug_8bbbdb0c_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_news_slug_8bbbdb0c_like ON public.cck_news USING btree (slug varchar_pattern_ops);


--
-- Name: cck_object_0382892d; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_0382892d ON public.cck_object USING btree (published_date);


--
-- Name: cck_object_0d111f56; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_0d111f56 ON public.cck_object USING btree (archived);


--
-- Name: cck_object_2dbcba41; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_2dbcba41 ON public.cck_object USING btree (slug);


--
-- Name: cck_object_5157e3c7; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_5157e3c7 ON public.cck_object USING btree (actual);


--
-- Name: cck_object_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_6a992d55 ON public.cck_object USING btree (index);


--
-- Name: cck_object_8f888fed; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_8f888fed ON public.cck_object USING btree (published);


--
-- Name: cck_object_activity_af31437c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_activity_af31437c ON public.cck_object_activity USING btree (object_id);


--
-- Name: cck_object_activity_f8a3193a; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_activity_f8a3193a ON public.cck_object_activity USING btree (activity_id);


--
-- Name: cck_object_be81f71c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_be81f71c ON public.cck_object USING btree (create_by_id);


--
-- Name: cck_object_d18b8f17; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_d18b8f17 ON public.cck_object USING btree (change_by_id);


--
-- Name: cck_object_fb216d9e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_fb216d9e ON public.cck_object USING btree (locale);


--
-- Name: cck_object_locale_0b2fdc9f_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_locale_0b2fdc9f_like ON public.cck_object USING btree (locale varchar_pattern_ops);


--
-- Name: cck_object_slug_b107cdf5_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_object_slug_b107cdf5_like ON public.cck_object USING btree (slug varchar_pattern_ops);


--
-- Name: cck_permit_0382892d; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_0382892d ON public.cck_permit USING btree (published_date);


--
-- Name: cck_permit_0d111f56; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_0d111f56 ON public.cck_permit USING btree (archived);


--
-- Name: cck_permit_2dbcba41; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_2dbcba41 ON public.cck_permit USING btree (slug);


--
-- Name: cck_permit_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_6a992d55 ON public.cck_permit USING btree (index);


--
-- Name: cck_permit_72122ce9; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_72122ce9 ON public.cck_permit USING btree (owner);


--
-- Name: cck_permit_8f888fed; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_8f888fed ON public.cck_permit USING btree (published);


--
-- Name: cck_permit_be81f71c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_be81f71c ON public.cck_permit USING btree (create_by_id);


--
-- Name: cck_permit_d18b8f17; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_d18b8f17 ON public.cck_permit USING btree (change_by_id);


--
-- Name: cck_permit_fb216d9e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_fb216d9e ON public.cck_permit USING btree (locale);


--
-- Name: cck_permit_locale_9a5761ff_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_locale_9a5761ff_like ON public.cck_permit USING btree (locale varchar_pattern_ops);


--
-- Name: cck_permit_owner_d89f4808_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_owner_d89f4808_like ON public.cck_permit USING btree (owner varchar_pattern_ops);


--
-- Name: cck_permit_slug_eeea6537_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX cck_permit_slug_eeea6537_like ON public.cck_permit USING btree (slug varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX django_admin_log_417f1b1c ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX django_admin_log_e8701ad4 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX django_session_de54fa62 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX django_site_domain_a2e37b91_like ON public.django_site USING btree (domain varchar_pattern_ops);


--
-- Name: proj_callback_9365d6e7; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_9365d6e7 ON public.proj_callback USING btree (site_id);


--
-- Name: proj_callback_9b18f05f; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_9b18f05f ON public.proj_callback USING btree (agent_id);


--
-- Name: proj_callback_9ed39e2e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_9ed39e2e ON public.proj_callback USING btree (state);


--
-- Name: proj_callback_adc78145; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_adc78145 ON public.proj_callback USING btree (sent_date);


--
-- Name: proj_callback_b068931c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_b068931c ON public.proj_callback USING btree (name);


--
-- Name: proj_callback_f7a42fe7; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_f7a42fe7 ON public.proj_callback USING btree (phone);


--
-- Name: proj_callback_name_96d86c67_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_name_96d86c67_like ON public.proj_callback USING btree (name varchar_pattern_ops);


--
-- Name: proj_callback_phone_409a4dd6_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_callback_phone_409a4dd6_like ON public.proj_callback USING btree (phone varchar_pattern_ops);


--
-- Name: proj_content_0382892d; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_0382892d ON public.proj_content USING btree (published_date);


--
-- Name: proj_content_06b2d4b9; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_06b2d4b9 ON public.proj_content USING btree (cluster);


--
-- Name: proj_content_0d111f56; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_0d111f56 ON public.proj_content USING btree (archived);


--
-- Name: proj_content_0fa44e66; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_0fa44e66 ON public.proj_content USING btree (mptt_right);


--
-- Name: proj_content_2dbcba41; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_2dbcba41 ON public.proj_content USING btree (slug);


--
-- Name: proj_content_402bbb5d; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_402bbb5d ON public.proj_content USING btree (mptt_level);


--
-- Name: proj_content_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_6a992d55 ON public.proj_content USING btree (index);


--
-- Name: proj_content_6be37982; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_6be37982 ON public.proj_content USING btree (parent_id);


--
-- Name: proj_content_8f888fed; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_8f888fed ON public.proj_content USING btree (published);


--
-- Name: proj_content_a0413764; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_a0413764 ON public.proj_content USING btree (mptt_left);


--
-- Name: proj_content_b6a36216; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_b6a36216 ON public.proj_content USING btree (mptt_tree);


--
-- Name: proj_content_be81f71c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_be81f71c ON public.proj_content USING btree (create_by_id);


--
-- Name: proj_content_d18b8f17; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_d18b8f17 ON public.proj_content USING btree (change_by_id);


--
-- Name: proj_content_fb216d9e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_fb216d9e ON public.proj_content USING btree (locale);


--
-- Name: proj_content_locale_001e7ad3_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_locale_001e7ad3_like ON public.proj_content USING btree (locale varchar_pattern_ops);


--
-- Name: proj_content_slug_791d5862_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_content_slug_791d5862_like ON public.proj_content USING btree (slug varchar_pattern_ops);


--
-- Name: proj_gallery_albom_4c9184f3; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albom_4c9184f3 ON public.proj_gallery_albom USING btree (public);


--
-- Name: proj_gallery_albom_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albom_6a992d55 ON public.proj_gallery_albom USING btree (index);


--
-- Name: proj_gallery_albom_b068931c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albom_b068931c ON public.proj_gallery_albom USING btree (name);


--
-- Name: proj_gallery_albom_c76a5e84; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albom_c76a5e84 ON public.proj_gallery_albom USING btree (active);


--
-- Name: proj_gallery_albom_name_c7196fe7_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albom_name_c7196fe7_like ON public.proj_gallery_albom USING btree (name varchar_pattern_ops);


--
-- Name: proj_gallery_albomgeneric_00049261; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albomgeneric_00049261 ON public.proj_gallery_albomgeneric USING btree (albom_id);


--
-- Name: proj_gallery_albomgeneric_417f1b1c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albomgeneric_417f1b1c ON public.proj_gallery_albomgeneric USING btree (content_type_id);


--
-- Name: proj_gallery_albomgeneric_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albomgeneric_6a992d55 ON public.proj_gallery_albomgeneric USING btree (index);


--
-- Name: proj_gallery_albomthrough_00049261; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albomthrough_00049261 ON public.proj_gallery_albomthrough USING btree (albom_id);


--
-- Name: proj_gallery_albomthrough_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albomthrough_6a992d55 ON public.proj_gallery_albomthrough USING btree (index);


--
-- Name: proj_gallery_albomthrough_f33175e6; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_albomthrough_f33175e6 ON public.proj_gallery_albomthrough USING btree (image_id);


--
-- Name: proj_gallery_image_599dcce2; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_image_599dcce2 ON public.proj_gallery_image USING btree (type);


--
-- Name: proj_gallery_image_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_image_6a992d55 ON public.proj_gallery_image USING btree (index);


--
-- Name: proj_gallery_image_b068931c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_image_b068931c ON public.proj_gallery_image USING btree (name);


--
-- Name: proj_gallery_image_c76a5e84; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_image_c76a5e84 ON public.proj_gallery_image USING btree (active);


--
-- Name: proj_gallery_image_name_438f4fae_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_image_name_438f4fae_like ON public.proj_gallery_image USING btree (name varchar_pattern_ops);


--
-- Name: proj_gallery_image_type_8cebf618_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_image_type_8cebf618_like ON public.proj_gallery_image USING btree (type varchar_pattern_ops);


--
-- Name: proj_gallery_imagegeneric_417f1b1c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_imagegeneric_417f1b1c ON public.proj_gallery_imagegeneric USING btree (content_type_id);


--
-- Name: proj_gallery_imagegeneric_6a992d55; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_imagegeneric_6a992d55 ON public.proj_gallery_imagegeneric USING btree (index);


--
-- Name: proj_gallery_imagegeneric_f33175e6; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_gallery_imagegeneric_f33175e6 ON public.proj_gallery_imagegeneric USING btree (image_id);


--
-- Name: proj_postbox_0c83f57c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_0c83f57c ON public.proj_postbox USING btree (email);


--
-- Name: proj_postbox_9365d6e7; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_9365d6e7 ON public.proj_postbox USING btree (site_id);


--
-- Name: proj_postbox_9b18f05f; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_9b18f05f ON public.proj_postbox USING btree (agent_id);


--
-- Name: proj_postbox_9ed39e2e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_9ed39e2e ON public.proj_postbox USING btree (state);


--
-- Name: proj_postbox_adc78145; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_adc78145 ON public.proj_postbox USING btree (sent_date);


--
-- Name: proj_postbox_b068931c; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_b068931c ON public.proj_postbox USING btree (name);


--
-- Name: proj_postbox_b5e3374e; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_b5e3374e ON public.proj_postbox USING btree (subject);


--
-- Name: proj_postbox_email_033c5661_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_email_033c5661_like ON public.proj_postbox USING btree (email varchar_pattern_ops);


--
-- Name: proj_postbox_name_b74bcde2_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_name_b74bcde2_like ON public.proj_postbox USING btree (name varchar_pattern_ops);


--
-- Name: proj_postbox_state_dd798295_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_state_dd798295_like ON public.proj_postbox USING btree (state varchar_pattern_ops);


--
-- Name: proj_postbox_subject_cbd599bd_like; Type: INDEX; Schema: public; Owner: vps
--

CREATE INDEX proj_postbox_subject_cbd599bd_like ON public.proj_postbox USING btree (subject varchar_pattern_ops);


--
-- Name: auth_group_permissions auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_activity_article cck_activity_article_change_by_id_8bad7434_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity_article
    ADD CONSTRAINT cck_activity_article_change_by_id_8bad7434_fk_auth_user_id FOREIGN KEY (change_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_activity_article cck_activity_article_create_by_id_d3acc17b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity_article
    ADD CONSTRAINT cck_activity_article_create_by_id_d3acc17b_fk_auth_user_id FOREIGN KEY (create_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_activity_article cck_activity_article_parent_id_2daa8730_fk_cck_activity_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity_article
    ADD CONSTRAINT cck_activity_article_parent_id_2daa8730_fk_cck_activity_id FOREIGN KEY (parent_id) REFERENCES public.cck_activity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_activity cck_activity_change_by_id_0711b730_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity
    ADD CONSTRAINT cck_activity_change_by_id_0711b730_fk_auth_user_id FOREIGN KEY (change_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_activity cck_activity_create_by_id_e42ab46f_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_activity
    ADD CONSTRAINT cck_activity_create_by_id_e42ab46f_fk_auth_user_id FOREIGN KEY (create_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_news cck_news_change_by_id_1bc680ef_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_news
    ADD CONSTRAINT cck_news_change_by_id_1bc680ef_fk_auth_user_id FOREIGN KEY (change_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_news cck_news_create_by_id_ae4544ed_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_news
    ADD CONSTRAINT cck_news_create_by_id_ae4544ed_fk_auth_user_id FOREIGN KEY (create_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_object_activity cck_object_activity_activity_id_d56b9999_fk_cck_activity_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object_activity
    ADD CONSTRAINT cck_object_activity_activity_id_d56b9999_fk_cck_activity_id FOREIGN KEY (activity_id) REFERENCES public.cck_activity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_object_activity cck_object_activity_object_id_ceb64583_fk_cck_object_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object_activity
    ADD CONSTRAINT cck_object_activity_object_id_ceb64583_fk_cck_object_id FOREIGN KEY (object_id) REFERENCES public.cck_object(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_object cck_object_change_by_id_b1ed2c1a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object
    ADD CONSTRAINT cck_object_change_by_id_b1ed2c1a_fk_auth_user_id FOREIGN KEY (change_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_object cck_object_create_by_id_dfdb299d_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_object
    ADD CONSTRAINT cck_object_create_by_id_dfdb299d_fk_auth_user_id FOREIGN KEY (create_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_permit cck_permit_change_by_id_46938fb1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_permit
    ADD CONSTRAINT cck_permit_change_by_id_46938fb1_fk_auth_user_id FOREIGN KEY (change_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: cck_permit cck_permit_create_by_id_b52e25f0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.cck_permit
    ADD CONSTRAINT cck_permit_create_by_id_b52e25f0_fk_auth_user_id FOREIGN KEY (create_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_callback proj_callback_agent_id_2d291643_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_callback
    ADD CONSTRAINT proj_callback_agent_id_2d291643_fk_auth_user_id FOREIGN KEY (agent_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_callback proj_callback_site_id_d6c6709c_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_callback
    ADD CONSTRAINT proj_callback_site_id_d6c6709c_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_content proj_content_change_by_id_d0d098b0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_content
    ADD CONSTRAINT proj_content_change_by_id_d0d098b0_fk_auth_user_id FOREIGN KEY (change_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_content proj_content_create_by_id_eb408158_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_content
    ADD CONSTRAINT proj_content_create_by_id_eb408158_fk_auth_user_id FOREIGN KEY (create_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_content proj_content_parent_id_75eab75e_fk_proj_content_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_content
    ADD CONSTRAINT proj_content_parent_id_75eab75e_fk_proj_content_id FOREIGN KEY (parent_id) REFERENCES public.proj_content(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_gallery_albomgeneric proj_gallery_albomge_albom_id_90d05db2_fk_proj_gallery_albom_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomgeneric
    ADD CONSTRAINT proj_gallery_albomge_albom_id_90d05db2_fk_proj_gallery_albom_id FOREIGN KEY (albom_id) REFERENCES public.proj_gallery_albom(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_gallery_albomthrough proj_gallery_albomth_albom_id_d9278177_fk_proj_gallery_albom_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomthrough
    ADD CONSTRAINT proj_gallery_albomth_albom_id_d9278177_fk_proj_gallery_albom_id FOREIGN KEY (albom_id) REFERENCES public.proj_gallery_albom(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_gallery_albomthrough proj_gallery_albomth_image_id_248d71ee_fk_proj_gallery_image_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomthrough
    ADD CONSTRAINT proj_gallery_albomth_image_id_248d71ee_fk_proj_gallery_image_id FOREIGN KEY (image_id) REFERENCES public.proj_gallery_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_gallery_albomgeneric proj_gallery_content_type_id_6604f974_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_albomgeneric
    ADD CONSTRAINT proj_gallery_content_type_id_6604f974_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_gallery_imagegeneric proj_gallery_content_type_id_9ae687f5_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_imagegeneric
    ADD CONSTRAINT proj_gallery_content_type_id_9ae687f5_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_gallery_imagegeneric proj_gallery_imagege_image_id_5d6cbdd2_fk_proj_gallery_image_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_gallery_imagegeneric
    ADD CONSTRAINT proj_gallery_imagege_image_id_5d6cbdd2_fk_proj_gallery_image_id FOREIGN KEY (image_id) REFERENCES public.proj_gallery_image(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_postbox proj_postbox_agent_id_84c303f6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_postbox
    ADD CONSTRAINT proj_postbox_agent_id_84c303f6_fk_auth_user_id FOREIGN KEY (agent_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: proj_postbox proj_postbox_site_id_cd03f46d_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: vps
--

ALTER TABLE ONLY public.proj_postbox
    ADD CONSTRAINT proj_postbox_site_id_cd03f46d_fk_django_site_id FOREIGN KEY (site_id) REFERENCES public.django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

